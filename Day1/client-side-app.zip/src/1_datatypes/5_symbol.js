// var result = 10 * "abc";
// console.log(result);

// Boolean Expression && Boolean Expression

// console.log(true && "abc");
// console.log(true && true);
// console.log(true && false);

// console.log(true && "abc" || "xyz");
// console.log(false && "abc" || "xyz");

// console.log(true ? "abc" : "xyz");
// console.log(false ? "abc" : "xyz");

{/* <h1 className={isSelect && "text-danger" || "text-success"}>
    Hello There
</h1> */}

// var obj = null;
// var obj = { id: 1 };

// if ((obj == null) || (obj == undefined)) { 
//     console.log("object is null or undefined");
// } else {
//     console.log("object is: ", obj);
// }

// if (!obj) { 
//     console.log("object is null or undefined");
// } else {
//     console.log("object is: ", obj);
// }

// console.log(Boolean(0));
// console.log(Boolean(1));
// console.log(Boolean(-1));
// console.log(Boolean(""));
// console.log(Boolean({}));
// console.log(Boolean(obj));

// var x;

// // I want to intialize x as 10, if x is undefined

// // if (!x) {
// //     x = 10;
// // }

// // x = x ? x : 10;

// x = x || 10;

// // x ||= 10;

// console.log(x);

// --------------------------------------------------------

// var a = 10;
// var b = "10";

// console.log(typeof a);
// console.log(typeof b);

// // console.log(a == b);        // Abstract Equality
// console.log(a === b);          // Strict Equality

// var a = { id: 10 };
// var b = { id: 10 };
// var c = b;

// console.log(a == b);        // Abstract Equality
// console.log(a === b);       // Strict Equality

// console.log(b == c);       // Abstract Equality
// console.log(b === c);      // Strict Equality

// -------------------------------------------------------------

// const color = "red";

// function isRedColor(str) {
//     // This fn should return true only if color constant is passed as argument
//     console.log(str === color);
// }

// isRedColor(color);
// isRedColor("red");

// var clr = "red";
// isRedColor(clr);

// ------------------------------- 
// const color = { clur: "red" };

// function isRedColor(str) {
//     // This fn should return true only if color constant is passed as argument
//     console.log(str === color);
// }

// isRedColor(color);
// isRedColor({ clur: "red" });

// var clr = { clur: "red" };
// isRedColor(clr);

// ------------------------------------------------- ECMASCRIPT 2015 - Symbol (Unique Immutables)

// const color = Symbol("red");

// function isRedColor(str) {
//     // This fn should return true only if color constant is passed as argument
//     console.log(str === color);
// }

// isRedColor(color);
// isRedColor(Symbol("red"));

// var clr = Symbol("red");
// isRedColor(clr);

// const color1 = Symbol("red");
// isRedColor(color1);

