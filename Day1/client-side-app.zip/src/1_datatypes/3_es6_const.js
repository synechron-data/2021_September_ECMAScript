'use strict'

// let a;
// console.log("a is: ", a);

// Error: 'Const declarations' require an initialization value.
// const a;
// console.log("a is: ", a);

// const env = "dev";
// console.log("env is: ", env);

// // Error: Assignment to constant variable.
// env = "prod";
// console.log("env is: ", env);

// -------------------------------------------------------------
// Const support block Scoping

// const env = "dev";
// console.log("Outside Block, env is: ", env);

// if (true) {
//     const env = "prod";
//     console.log("Inside Block, env is: ", env);
// }

// ----------------------------------------------------

const obj = { id: 1 };
console.log(obj);

obj.id = 1000;
// obj = { name: "Manish" };         // Error: Assignment to constant variable.  
console.log(obj);
