// Import an entire module for side effects only, without importing anything.
// This will run the module's global code, but doesn't import any values.

// import './1_functions/1_fn_overloading';
// import './1_functions/2_iife';
// import './1_functions/3_overloading_assignment';
// import './1_functions/4_arrow_fn';
// import './1_functions/5_fn_as_arguments';
// import './1_functions/6_closure';
// import './1_functions/7_context';
// import './1_functions/8_currying';
// import './1_functions/9_hof';

// import './2_objects/1_object_creation';
// import './2_objects/2_object_type';
// import './2_objects/3_object_methods';
// import './2_objects/4_custom_type';
// import './2_objects/5_using_prototype';
// import './2_objects/6_es6_class';
// import './2_objects/7_compare';
// import './2_objects/8_es5_properties';
// import './2_objects/9_es6_properties';
// import './2_objects/10_es5_inheritance';
import './2_objects/11_es6.inheritance';