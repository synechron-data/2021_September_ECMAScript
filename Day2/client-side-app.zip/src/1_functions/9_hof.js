// function greaterThan(n, m) {
//     return m > n;
// }

// console.log(greaterThan(5, 6));
// console.log(greaterThan(5, 4));
// console.log(greaterThan(5, 10));

// function greaterThan(n) {
//     return function (m) {
//         return m > n;
//     }
// }

// let greaterThan5 = greaterThan(5);

// console.log(greaterThan5(6));
// console.log(greaterThan5(4));
// console.log(greaterThan5(10));

// -------------------------------------------------------------
// function add(x, y) {
//     console.log(`add called with args, ${x}, ${y}`);
//     return x + y;
// }

// function sub(x, y) {
//     console.log(`sub called with args, ${x}, ${y}`);
//     return x - y;
// }

// // I want to log the arguments passed to the add and sub function

// console.log(add(2, 3));
// console.log(sub(20, 3));

// -------------------------------------

// function add(x, y) {
//     return x + y;
// }

// function sub(x, y) {
//     return x - y;
// }

// // I want to log the arguments passed to the add and sub function

// function logDecorator(fn) {
//     return function (...args) {
//         console.log(`${fn.name} called with arguments as ${args}`);
//         let result = fn(...args);
//         return result;
//     }
// }

// var addWithLogger = logDecorator(add);
// var subWithLogger = logDecorator(sub);

// console.log(addWithLogger(2, 3));
// console.log(subWithLogger(20, 3));

// ----------------------------------------------------------------------
// Handle Exceptions of the code using Higher Order Function

function m1(x, y) {
    throw Error("Invalid Arguments....");
}

function errorHandlerDecorator(fn) {
    return function (...args) {
        try {
            let result = fn(...args);
            return result;
        } catch (e) {
            console.error(e.message);
        }
    }
}

// try {
//     m1(20, 30);
// } catch (e) {
//     console.error(e.message);
// }

errorHandlerDecorator(m1)(20, 30);