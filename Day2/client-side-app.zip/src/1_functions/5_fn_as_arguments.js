// document.getElementById("b1").addEventListener("click", function () {

// });

// $(document).ready(function () {
//     $("#b1").click(function () {

//     });
// });

// window.setInterval(function () { }, 2000);

// window.setTimeout(function () { }, 2000);

// ------------------------------------------------------------

// var employees = [
//     { id: 1, name: "Manish", city: "Pune" },
//     { id: 2, name: "Neeraj", city: "Delhi" },
//     { id: 3, name: "Abhijeet", city: "Pune" }
// ];

// ---------------------------------------

// var pune_employees = [];

// for (let i = 0; i < employees.length; i++) {
//     if (employees[i].city === "Pune")
//         pune_employees.push(employees[i]);
// }

// console.log(pune_employees);

// ---------------------------------------

// var pune_employees = [];

// function filterLogic(item) {
//     return item.city === "Pune";
// }

// for (let i = 0; i < employees.length; i++) {
//     if (filterLogic(employees[i]))
//         pune_employees.push(employees[i]);
// }

// console.log(pune_employees);

// ----------------------------------------

// function filterLogic(item) {
//     return item.city === "Pune";
// }

// var pune_employees = employees.filter(filterLogic);

// console.log(pune_employees);

// ----------------------------------------

// var pune_employees = employees.filter(function (item) {
//     return item.city === "Pune";
// });

// console.log(pune_employees);

// ----------------------------------------

// var pune_employees = employees.filter((item) => {
//     return item.city === "Pune";
// });

// console.log(pune_employees);

// ----------------------------------------

// var pune_employees = employees.filter(item => item.city === "Pune");
// console.log(pune_employees);

// ------------------------------------------------------------

// Dev 1
// function getString() {
//     const strArr = ["NodeJS", "ReactJS", "Angular", "ExtJS", "jQuery"];
//     var str = strArr[Math.floor(Math.random() * strArr.length)];
//     return str;
// }

// // Dev 2

// // var s = getString();
// // console.log(s);

// setInterval(() => {
//     var s = getString();
//     console.log(s);
// }, 2000);

// 1 - 1000     
// 2 - 3000     
// 3 - 1000     

// Angular - 1
// ReactJS - 3
// ExtJS - 2

// ----------------------------------------------------------------------

// Dev 1
// function pushString(cb) {
//     const strArr = ["NodeJS", "ReactJS", "Angular", "ExtJS", "jQuery"];
//     setInterval(() => {
//         var str = strArr[Math.floor(Math.random() * strArr.length)];
//         cb(str);
//     }, 2000);
// }

// // Dev 2
// // function process(s) {
// //     console.log(s);
// // }

// // pushString(process);

// // pushString(function (s) {
// //     console.log(s);
// // });

// pushString((s) => {
//     console.log("C1 -", s);
// });

// pushString((s) => {
//     console.log("C2 -", s);
// });

// ----------------------------------------------------------------------------
function pushString(cb, time) {
    const strArr = ["NodeJS", "ReactJS", "Angular", "ExtJS", "jQuery"];

    var sInt = setInterval(() => {
        var str = strArr[Math.floor(Math.random() * strArr.length)];
        cb(str);
    }, 2000);

    setTimeout(() => {
        clearInterval(sInt);
    }, time);
}

pushString((s) => {
    console.log("C1 -", s);
}, 10000);

pushString((s) => {
    console.log("C2 -", s);
}, 5000);
