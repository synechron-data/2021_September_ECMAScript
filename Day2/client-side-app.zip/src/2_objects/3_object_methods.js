// ---------------------------------------------------- Object.assign (Shallow Copy)

// let source = { id: 1, name: "Manish", address: { city: "Pune" } };
// let target = { lastname: "Sharma" };

// let obj1 = Object.assign({}, source);
// console.log(obj1);

// let obj2 = Object.assign(target, source);
// console.log(obj2);

// console.log(source);
// console.log(target);

// console.log(target === obj2);

// ---------------------------------------------------- Object.create
// Creates a new object, using an existing object as the prototype of the newly created object.

// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// let obj1 = Object.assign({}, source);
// let obj2 = Object.create(source);

// console.log("Source:", source);
// console.log("Assign:", obj1);
// console.log("Create:", obj2);

// ------------------------------------------------------

let source = { id: 1, name: "Manish" };

// // Add a New Property
// source.city = "Pune";
// console.log(source);
// // Delete a Property
// delete source.name;
// console.log(source);
// // Modify the Property Value
// source.id = 100;
// console.log(source);

// ------------------------------------------------
// Add a New Property - Not Allowed
// Delete a Property - Allowed
// Modify the Property Value - Allowed

// Object.preventExtensions(source);

// source.id = 100;
// console.log(source);

// delete source.name;
// console.log(source);

// if (Object.isExtensible(source)) {
//     source.city = "Pune";
//     console.log(source);
// }

// ------------------------------------------------
// Add a New Property - Not Allowed
// Delete a Property - Not Allowed
// Modify the Property Value - Allowed

// Object.seal(source);

// source.id = 100;
// console.log(source);

// if (!Object.isSealed(source)) {
//     delete source.name;
//     console.log(source);

//     source.city = "Pune";
//     console.log(source);
// }

// ------------------------------------------------
// Add a New Property - Not Allowed
// Delete a Property - Not Allowed
// Modify the Property Value - Not Allowed

Object.freeze(source);

if (!Object.isFrozen(source)) {
    source.id = 100;
    console.log(source);

    delete source.name;
    console.log(source);

    source.city = "Pune";
    console.log(source);
}