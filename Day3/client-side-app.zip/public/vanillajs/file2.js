// Dev 2
function hello() {
    console.log("Hello from File Two");
}