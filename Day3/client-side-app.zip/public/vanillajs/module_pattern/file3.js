// Dev 3

var dev1;

(function (ns) {
    function hi() {
        console.log("Hi from File Three");
    }

    ns.hi = hi;
})(dev1 = dev1 || {});
