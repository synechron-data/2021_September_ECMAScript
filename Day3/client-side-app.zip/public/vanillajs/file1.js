// Dev 1
function hello() {
    console.log("Hello from File One");
}