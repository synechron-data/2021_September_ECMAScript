var map = new Map();
var wmap = new WeakMap();

(function () {
    var o1 = { id: 1 };
    var o2 = { id: 2 };

    map.set(o1, "This is the value for first object");
    wmap.set(o2, "This is the value for second object");

    for (const item of map) {
        console.log(item);
    }

    // Error
    // for (const item of wmap) {
    //     console.log(item);
    // }
})();

console.log("Execution Completed....");