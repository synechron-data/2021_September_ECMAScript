// console.log(Object.getOwnPropertyNames(Symbol));

// let nameSymbol = Symbol("name");

// let obj = {
//     id: 1,
//     [nameSymbol]: 'Manish'
// };

// console.log(Object.getOwnPropertyNames(obj));
// console.log(Object.getOwnPropertySymbols(obj));

// var arr = [];
// console.log(Object.getOwnPropertyNames(arr));
// console.log(Object.getOwnPropertySymbols(Array.prototype));

class CustomArray extends Array {
    static get [Symbol.species]() { return Array; }
}

let arr = new CustomArray(10, 20, 30);
console.log(arr);

let resultArr = arr.map(n => n * 10) 

console.log(resultArr instanceof CustomArray);
console.log(resultArr instanceof Array);
