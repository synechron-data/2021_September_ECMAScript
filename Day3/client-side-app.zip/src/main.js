// Import an entire module for side effects only, without importing anything.
// This will run the module's global code, but doesn't import any values.

// import './1_objects/1_es6_static';

// import './2_collections/1_arrays';
// import './2_collections/2_es6_map';
// import './2_collections/3_es6_weak_map';
// import './2_collections/4_es6_set';

// import './3_iterators/1_well_known_symbols';
// import './3_iterators/2_custom_iterable';
// import './3_iterators/3_generators';

// import './4_modules/usage';

// import './5_promise/1_creating_promise';
// import './5_promise/2_chaining_promise';
// import './5_promise/3_promise_methods';

// import './6_ajax/dom_handler';

// import './7_misc/1_es7_features';
// import './7_misc/2_es8_object_methods';
// import './7_misc/3_es8_string_padding';
// import './7_misc/4_es8_trailing_commas';
// import './7_misc/5_es9_async_iterators';
import './7_misc/6_es9_tagged_template_literals';

