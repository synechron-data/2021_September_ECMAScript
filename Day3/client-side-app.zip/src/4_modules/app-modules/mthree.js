export default function test(x) {
    return `Tested: ${x}`;
}