export default function check(x) {
    return `Checked: ${x}`;
}