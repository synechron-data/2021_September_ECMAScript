import square from './mone';
import check from './mtwo';
import test from './mthree';

// export {
//     square,
//     check,
//     test
// };

export default {
    square,
    check,
    test
};