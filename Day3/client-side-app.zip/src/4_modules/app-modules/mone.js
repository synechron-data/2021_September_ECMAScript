export default function square(x) {
    return x * x;
}