var person_name = "Manish";
var person_lname = "Sharma";

console.log(`Hello ${person_name}; How are you`);

function tagFunc(strings, exp) {
    console.log(strings);
    console.log(exp);

    // return exp + " " + strings[0] + strings[1];
}

// console.log(tagFunc`Hello ${person_name}; How are you`);
// console.log(String.raw`Hello ${person_name}; How are you`);


function tagFuncNew(strings, ...exp) {
    console.log(strings);
    console.log(exp);

    // return exp + " " + strings[0] + strings[1];
}

console.log(tagFuncNew`Hello ${person_name}; How are you ${person_lname}`);
