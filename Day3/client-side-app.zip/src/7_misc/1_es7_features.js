// let result = Math.pow(2, 4);
// console.log(result);

// // Exponentiation Operator
// let result1 = 2 ** 4;
// console.log(result1);

// let a = 2, b = 4;
// a **= b;
// // a = a ** b;
// console.log(a);

// Negative base should be kept in ()
// let result = (-3) ** 7;
// console.log(result);

// ------------------------------------------------------------- Array.includes()
let arr = ["ReactJS", "Angular", "ExtJS"];

// Before ES7

// console.log(arr.indexOf('ReactJS'));
// console.log(Boolean(arr.indexOf('ReactJS')));

// if (arr.indexOf('ReactJS')) {
//     console.log("React is available...");
// } else {
//     console.log("React is not available...");
// }

// console.log(arr.indexOf('VueJS'));
// console.log(Boolean(arr.indexOf('VueJS')));

// if (arr.indexOf('VueJS')) {
//     console.log("VueJS is available...");
// } else {
//     console.log("VueJS is not available...");
// }

// if (arr.indexOf('ReactJS') !== -1) {
//     console.log("React is available...");
// } else {
//     console.log("React is not available...");
// }

// In ES7
if (arr.includes('ReactJS')) {
    console.log("React is available...");
} else {
    console.log("React is not available...");
}

if (arr.includes('VueJS')) {
    console.log("VueJS is available...");
} else {
    console.log("VueJS is not available...");
}