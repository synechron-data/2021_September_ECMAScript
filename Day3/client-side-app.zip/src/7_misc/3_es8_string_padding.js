console.log("Manish");
console.log("Manish".padStart(20));
console.log("Satish Sharma".padStart(20));

console.log("0.00".padStart(20));
console.log("10000.00".padStart(20));
console.log("1000000.00".padStart(20));

console.log("100.00".padStart(20, '-'));
console.log("10000.00".padStart(20, '-'));

console.log("Manish".padEnd(10, '-'), "Sharma");
console.log("Manish".padEnd(5, '-'), "Sharma");         // No Padding
