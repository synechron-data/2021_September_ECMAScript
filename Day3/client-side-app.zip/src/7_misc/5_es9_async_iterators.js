// // function getIterator() {
// //     const arr = [1, 2, 3, 4, 5];

// //     return {
// //         next: function () {
// //             if (arr.length) {
// //                 return {
// //                     value: arr.shift(),
// //                     done: false
// //                 }
// //             } else {
// //                 return {
// //                     done: true
// //                 };
// //             }
// //         }
// //     };
// // }

// // var it = getIterator();

// // (function () {
// //     console.log(it.next());
// //     console.log(it.next());
// //     console.log(it.next());
// //     console.log(it.next());
// //     console.log(it.next());
// //     console.log(it.next());
// // })();

// function asynIterator() {
//     const arr = [1, 2, 3, 4, 5];

//     return {
//         next: function () {
//             if (arr.length) {
//                 return Promise.resolve({
//                     value: arr.shift(),
//                     done: false
//                 });
//             } else {
//                 return Promise.resolve({
//                     done: true
//                 });
//             }
//         }
//     };
// }

// // var it = asynIterator();

// // (async function () {
// //     await it.next().then(console.log);
// //     await it.next().then(console.log);
// //     await it.next().then(console.log);
// //     await it.next().then(console.log);
// //     await it.next().then(console.log);
// //     await it.next().then(console.log);
// // })();

// var asyncIterable = {
//     [Symbol.asyncIterator]: asynIterator
// };

// // for-await-of
// (async function () {
//     for await (const item of asyncIterable) {
//         console.log(item);
//     }
// })();

// ------------------------------------------------------------------------- Async Generator
var asyncIterable = {
    [Symbol.asyncIterator]: async function* asyncGenerator() {
        var array = [Promise.resolve(1), Promise.resolve(2), Promise.resolve(3), Promise.resolve(4)];

        while (array.length) {
            yield await array.shift();
        }
    }
};

(async function () {
    for await (const item of asyncIterable) {
        console.log(item);
    }
})();

console.log("Last Line");